<div class="container">
    <div class="row">
        <div class ="col-xs-12">

            <div class="alert alert-info">
                Selamat datang kembali <strong><?=$_SESSION['nama']?></strong>
            </div>
        </div>
    </div>
    <div class="row">
        <!--colomn kedua-->
        <div class="col-sm-12 col-xs-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Halaman Utama Sekolah Dasar Swasta Islam Ar-Risalah</h3>
                </div>
                <div class="panel-body">
                     <table id="dtskripsi" class="table table-bordered table-striped table-hover">
                       <thead>
                          <p align="center"><img src="img/tk.png"></img></p>
                          <p class="label-title" align="center"><strong>SDS Islam Ar-Risalah</strong></p>
                          <p class="col-sm-12 col-xs-12" align="center">
                            Selamat datang di halaman utama Sekolah Dasar Swasta Islam Ar-Risalah.<br>
                            Melalui halaman ini anda dapat melakukan pengelolaan data anak didik, pengelolaan data guru. <br>
                            Akses menu Master Data pada bagian atas sistem untuk pengelolaan data anak didik dan data guru.<br>
                            Untuk mengelola laporan, dapat dilakukan dengan mengakses menu report pada bagian atas sistem.<br>
                            Akses menu User untuk mengelola informasi tentang user yang login.<br><br><br>

                          </p>

                         </thead


                    </table>
                </div>
            </div>
        </div>
</div>
