<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <div class="panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title"><span class="fa fa-user-plus"></span> About</h3>
                </div>
                <div class="panel-body">
                    <table id="dtskripsi" class="table table-bordered table-striped table-hover">
                        <thead>
                            <p align="center"><img src="img/tk.png"></img></p>
                            <label class="col-sm-12 control-label"><center><strong>SISTEM INFORMASI SDS<br>  ISLAM AR-RISALAH</strong></center></label>
                        </thead>
                        <tbody>
                          <div class="col-sm-2" align="center">

                          </div>
                          <div class="col-sm-8" align="center">
                            <br>
                            SDS Islam Ar-Risalah merupakan Sekolah Dasar Swasta 3 Bahasa (Inggris, Indonesia, Arab) yang di dirikan oleh Yayasan Pembangunan Islam dengan tujuan membantu pendidikan anak-anak yang kurang mampu di lokasi  JL. DARMAWANGSA NO.116B RAMBIPUJI, Rambigundam, Kec. Rambipuji, Kab. Jember Prov. Jawa Timur.
                            <br><br><br>
                          </div>
                          <div class="col-sm-2" align="center">
                          </div>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>
