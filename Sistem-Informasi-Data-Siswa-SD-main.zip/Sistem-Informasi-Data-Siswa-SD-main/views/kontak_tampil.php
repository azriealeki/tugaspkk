<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <div class="panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title"><span class="fa fa-user-plus"></span> Kontak</h3>
                </div>
                <div class="panel-body">
                    <table id="dtskripsi" class="table table-bordered table-striped table-hover">
                        <thead>
                            <label class="col-sm-12 control-label"><center><strong>SDS Islam Ar-Risalah</strong></center></label>
                            <p align="center">
                            JL. DARMAWANGSA NO.116B RAMBIPUJI, Rambigundam, Kec. Rambipuji,<br> Jember, Jawa Timur, Kode Pos : 68152
                            </p>
                        </thead>
                        <tbody>
                          <div class="col-sm-2" align="center">

                          </div>
                          <div class="col-sm-8" align="center">
                            <br>
                            Tc. Onick (082113675398)<br>
                            Tc. Agung (087623988122)<br>
                            Tc. Harun (088645289133)<br>
                            <br>
                          </div>
                          <div class="col-sm-2" align="center">
                          </div>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>
